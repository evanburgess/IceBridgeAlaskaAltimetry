IceBridgeAlaskaAltimetry is a python package which enables you to interface with UAF LiDAR 
Altimetry data stored in a postgres database such as ice2oceans.cloudapp.net.